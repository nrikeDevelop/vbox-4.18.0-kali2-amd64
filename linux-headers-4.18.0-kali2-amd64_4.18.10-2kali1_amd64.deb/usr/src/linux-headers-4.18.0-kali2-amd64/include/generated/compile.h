/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP Debian 4.18.10-2kali1 (2018-10-09)"
#define LINUX_COMPILE_BY "devel"
#define LINUX_COMPILE_HOST "kali.org"
#define LINUX_COMPILER "gcc version 7.3.0 (Debian 7.3.0-29)"
