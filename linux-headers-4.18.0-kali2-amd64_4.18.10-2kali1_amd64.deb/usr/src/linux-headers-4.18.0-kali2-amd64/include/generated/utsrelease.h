#define UTS_RELEASE "4.18.0-kali2-amd64"
