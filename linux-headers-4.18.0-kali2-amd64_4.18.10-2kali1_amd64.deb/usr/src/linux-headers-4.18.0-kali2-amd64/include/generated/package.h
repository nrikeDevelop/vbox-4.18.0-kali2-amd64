#define LINUX_PACKAGE_ID " Debian 4.18.10-2kali1"
